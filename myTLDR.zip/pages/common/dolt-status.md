# dolt status

> Display the status of the database session.
> More information: <https://docs.dolthub.com/cli-reference/cli#dolt-status>.

- Display the status:

`dolt status`
