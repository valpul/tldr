# dolt version

> Displays the current dolt CLI version.
> More information: <http://github.com/dolthub/dolt>.

- Display version:

`dolt version`
